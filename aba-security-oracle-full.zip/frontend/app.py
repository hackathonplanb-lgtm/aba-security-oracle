
import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="Aba Security Oracle", layout="wide")
st.markdown("<h1 style='text-align:center; color:red;'>ABA SECURITY ORACLE</h1>", unsafe_allow_html=True)
st.markdown("**Retrained with 55+ REAL Aba Incidents • Team Udo 2025**")

incidents = pd.read_csv("data/incidents.csv")
police = pd.read_csv("data/police.csv")

m = folium.Map(location=[5.107, 7.369], zoom_start=14, tiles="CartoDB positron")

for _, row in incidents.iterrows():
    folium.CircleMarker(
        [row.lat, row.lon], radius=8, color="crimson", fill=True,
        popup=f"<b>{row['type']}</b><br>{row.date}<br>{row.desc}"
    ).add_to(m)

for _, row in police.iterrows():
    folium.CircleMarker([row.lat, row.lon], radius=12, color="darkblue", fill=True).add_to(m)

folium.PolyLine([[5.116,7.355],[5.105,7.370]], color="red", weight=16).add_to(m)
folium.PolyLine([[5.095,7.375],[5.080,7.390]], color="purple", weight=12, dash_array="10").add_to(m)

st_folium(m, width=1400, height=800)
